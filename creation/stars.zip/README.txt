A Pen created at CodePen.io. You can find this one at https://codepen.io/giana/pen/qbWNYy.

 See also: <a href="http://codepen.io/giana/pen/bEGxoe">Galaxy</a>

Edit: Big thanks to @lightest and @jackrugile for the performance boost.

I'm getting super laggy performance on Firefox even with a low (50-100) number of particles and bad flickering on Chrome. Any ideas what it could be?

Edit: I mean. That flickering is totally intentional. Because they're stars. And stars appear to flicker.