A Pen created at CodePen.io. You can find this one at https://codepen.io/n-sayenko/pen/qOXKVr.

 playing around with particles.js